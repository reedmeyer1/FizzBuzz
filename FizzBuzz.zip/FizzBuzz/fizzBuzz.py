print('Welcome to the FizzBuzz program!\n\
 \n This game works by generating a random number between 1 and 100.\n\
 Any numbers divisble by 3 or 5 will output Fizz or Buzz respectively.\n\
 And numbers that meet both critera will output FizzBuzz!\n ' )

import random
docalc = True
while (docalc):
    while(True):
        try:
            randVar = random.randint(1,100)
            print('The number is...', randVar)
    
            fizzVar = float(randVar / 3)
            fizzTest = fizzVar.is_integer()

            buzzVar = float(randVar / 5)
            buzzTest = buzzVar.is_integer()
    
            if fizzTest == True and buzzTest == False:
                randVar = 'Fizz'
                print(randVar)
                break;
            elif buzzTest == True and fizzTest == False:
                randVar = 'Buzz'
                print(randVar)
                break;
            elif buzzTest == True and fizzTest == True:
                randVar = 'FizzBuzz'
                print(randVar)
                break;
            else:
                print(randVar)
                break;
        except:
            break;
    antclc = input('Would you like to try a different number? (y/n): ')
    if (antclc != 'y'):
        print(' \n Thank you for playing!')
        docalc = False
        
